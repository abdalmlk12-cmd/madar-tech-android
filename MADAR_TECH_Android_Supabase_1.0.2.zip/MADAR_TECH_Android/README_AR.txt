MADAR TECH – مدار تك | تطبيق أندرويد
====================================

التحديث الحالي:
- واجهة المتجر تقرأ المنتجات النشطة من Supabase (public.products).
- البحث والتصنيفات تعمل على المنتجات المحمّلة من قاعدة البيانات.
- نموذج طلب الخدمة يحاول حفظ الطلب في public.service_requests ثم يفتح واتساب برسالة جاهزة.
- لوحة إدارة داخل التطبيق مع تسجيل دخول Supabase Auth والتحقق عبر RPC public.is_admin().
- لوحة الإدارة تعرض أحدث الطلبات وتتيح إضافة/تعديل المنتجات حسب الأعمدة المعروفة في جدول products.
- رابط خرائط Google لموقع مدار تك في الموصل.

إعداد Supabase المستخدم:
Project URL: https://bywxvsdbhsawtlhgbrec.supabase.co
Client key: publishable key (مضمّنة في واجهة العميل، وليست service_role key).

مهم للأمان:
- لا تضع service_role key داخل التطبيق مطلقاً.
- يجب أن تبقى RLS مفعّلة على الجداول.
- المنتجات العامة تقرأ فقط المنتجات is_active=true.
- صلاحية الإدارة تعتمد على public.is_admin() وعضوية المستخدم في admin_users.

ملاحظة توافق قاعدة البيانات:
الواجهة تتوقع في products حقولاً شائعة مثل name/title, description, category, price, image_url, is_active، وفي service_requests حقول customer_name, customer_phone, request_type, details. إذا كانت أسماء الأعمدة الفعلية مختلفة فستظهر رسالة خطأ من Supabase وتحتاج مطابقة أسماء الحقول قبل اعتماد النسخة النهائية. لم يتسنّ الاتصال المباشر بالمشروع من بيئة البناء الحالية للتحقق من المخطط أو تجربة عمليات الكتابة.

بناء APK:
افتح مجلد MADAR_TECH_Android في Android Studio ثم نفّذ Build > Build APK(s).
أو ارفع المشروع إلى GitHub وشغّل GitHub Actions باسم Build MADAR TECH APK، ثم نزّل artifact باسم MADAR-TECH-debug-apk.

التطبيق لم يُبنَ أو يُختبر على جهاز فعلي في بيئة العمل الحالية لعدم توفر Android SDK/Gradle هنا.


تحديث 1.0.2: تم توصيل واجهة المتجر بواجهة REST الخاصة بـ Supabase باستخدام المفتاح publishable، وإضافة تسجيل دخول المشرف والتحقق عبر RPC is_admin، وإضافة وتعديل وحذف المنتجات، وقراءة طلبات العملاء وإرسال الطلبات إلى service_requests. يجب اختبار السياسات وأسماء الأعمدة على المشروع الفعلي قبل الاعتماد النهائي.
