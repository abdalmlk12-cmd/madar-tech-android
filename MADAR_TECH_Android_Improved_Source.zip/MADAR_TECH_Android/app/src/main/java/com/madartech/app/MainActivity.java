package com.madartech.app;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.content.Intent;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private WebView webView;
    private FrameLayout root;
    private LinearLayout loadingPanel;
    private TextView loadingText;
    private boolean pageLoaded = false;
    private static final int NAVY = Color.rgb(4, 19, 38);

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        Window w = getWindow();
        w.setStatusBarColor(NAVY);
        w.setNavigationBarColor(NAVY);
        w.getDecorView().setSystemUiVisibility(0);
        buildScreen();
        configureWebView();
        if (state == null) webView.loadUrl("file:///android_asset/site/index.html");
        else webView.restoreState(state);
    }

    private void buildScreen() {
        root = new FrameLayout(this);
        root.setBackgroundColor(Color.rgb(244,248,252));
        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(244,248,252));
        root.addView(webView, new FrameLayout.LayoutParams(-1,-1));

        loadingPanel = new LinearLayout(this);
        loadingPanel.setGravity(Gravity.CENTER);
        loadingPanel.setOrientation(LinearLayout.VERTICAL);
        loadingPanel.setPadding(32,32,32,32);
        loadingPanel.setBackgroundColor(NAVY);
        TextView logo = new TextView(this);
        logo.setText("M"); logo.setTextColor(Color.WHITE); logo.setTextSize(36);
        logo.setTypeface(Typeface.DEFAULT, Typeface.BOLD); logo.setGravity(Gravity.CENTER);
        GradientDrawable mark = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(8,120,220),Color.rgb(53,197,239)});
        mark.setCornerRadius(28); logo.setBackground(mark);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(92,92);
        lp.bottomMargin=18; loadingPanel.addView(logo,lp);
        TextView title = new TextView(this);
        title.setText("MADAR TECH"); title.setTextColor(Color.WHITE); title.setTextSize(24);
        title.setTypeface(Typeface.DEFAULT,Typeface.BOLD); loadingPanel.addView(title);
        TextView subtitle = new TextView(this);
        subtitle.setText("مدار تك | حلول المراقبة والشبكات"); subtitle.setTextColor(Color.LTGRAY);
        subtitle.setTextSize(14); subtitle.setGravity(Gravity.CENTER); loadingPanel.addView(subtitle);
        ProgressBar progress = new ProgressBar(this);
        LinearLayout.LayoutParams pp=new LinearLayout.LayoutParams(54,54); pp.topMargin=28;
        loadingPanel.addView(progress,pp);
        loadingText = new TextView(this); loadingText.setText("جاري تجهيز التطبيق...");
        loadingText.setTextColor(Color.WHITE); loadingText.setTextSize(13);
        LinearLayout.LayoutParams tp=new LinearLayout.LayoutParams(-2,-2);tp.topMargin=12;
        loadingPanel.addView(loadingText,tp);
        root.addView(loadingPanel,new FrameLayout.LayoutParams(-1,-1));
        setContentView(root);
    }

    private void configureWebView() {
        WebSettings s=webView.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setDatabaseEnabled(true);
        s.setLoadsImagesAutomatically(true); s.setAllowFileAccess(true); s.setAllowContentAccess(true);
        s.setSupportZoom(false); s.setBuiltInZoomControls(false); s.setDisplayZoomControls(false);
        s.setDefaultTextEncodingName("UTF-8"); s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebChromeClient(new WebChromeClient(){
            @Override public void onProgressChanged(WebView view,int progress){
                if(progress>=100 && pageLoaded) hideLoading();
            }
        });
        webView.setWebViewClient(new WebViewClient(){
            @Override public void onPageStarted(WebView view,String url,android.graphics.Bitmap icon){
                pageLoaded=false; showLoading("جاري تحميل واجهة مدار تك...");
            }
            @Override public void onPageFinished(WebView view,String url){
                pageLoaded=true; hideLoading();
                // Route links opened with target=_blank into the current WebView.
                view.evaluateJavascript("(function(){document.querySelectorAll('a[target=\"_blank\"]').forEach(function(a){a.removeAttribute('target');});})();",null);
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){
                return routeUrl(request.getUrl());
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return routeUrl(Uri.parse(url));}
            @Override public void onReceivedError(WebView view,WebResourceRequest request,WebResourceError error){
                if(request.isForMainFrame()){
                    loadingText.setText("تعذر فتح التطبيق. تحقق من الملفات ثم أعد المحاولة.");
                    showLoading("تعذر تحميل الواجهة");
                    Toast.makeText(MainActivity.this,"حدث خطأ أثناء تشغيل التطبيق",Toast.LENGTH_LONG).show();
                }
            }
        });
    }

    private void showLoading(String message){
        if(loadingText!=null) loadingText.setText(message);
        if(loadingPanel!=null) loadingPanel.setVisibility(View.VISIBLE);
    }
    private void hideLoading(){if(loadingPanel!=null) loadingPanel.setVisibility(View.GONE);}

    private boolean routeUrl(Uri uri){
        String scheme=uri.getScheme()==null?"":uri.getScheme().toLowerCase();
        if(scheme.equals("file")||scheme.equals("about")||scheme.equals("javascript")) return false;
        try {
            Intent intent;
            if(scheme.equals("tel")) intent=new Intent(Intent.ACTION_DIAL,uri);
            else if(scheme.equals("mailto")) intent=new Intent(Intent.ACTION_SENDTO,uri);
            else if(scheme.equals("http")||scheme.equals("https")) intent=new Intent(Intent.ACTION_VIEW,uri);
            else intent=new Intent(Intent.ACTION_VIEW,uri);
            startActivity(intent);
        } catch(Exception e){Toast.makeText(this,"لا يوجد تطبيق مناسب لفتح هذا الرابط",Toast.LENGTH_SHORT).show();}
        return true;
    }

    @Override protected void onSaveInstanceState(Bundle out){if(webView!=null)webView.saveState(out);super.onSaveInstanceState(out);}
    @Override public void onBackPressed(){if(webView!=null&&webView.canGoBack())webView.goBack();else super.onBackPressed();}
    @Override protected void onPause(){if(webView!=null)webView.onPause();super.onPause();}
    @Override protected void onResume(){super.onResume();if(webView!=null)webView.onResume();}
    @Override protected void onDestroy(){if(webView!=null){webView.stopLoading();webView.loadUrl("about:blank");webView.destroy();webView=null;}super.onDestroy();}
}
